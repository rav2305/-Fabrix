import os
import threading
import webbrowser
import time
import sys
from app import app

def start_server():
    # use_reloader=False is required when running inside PyInstaller
    app.run(host='0.0.0.0', port=5000, use_reloader=False)

if __name__ == '__main__':
    print("Starting Fabrix Shop Manager...")
    
    # Start Flask server in the background
    server_thread = threading.Thread(target=start_server, daemon=True)
    server_thread.start()
    
    # Wait 2 seconds to ensure the server is up
    time.sleep(2)
    
    # Automatically open the default web browser to the app
    webbrowser.open('http://127.0.0.1:5000')
    
    print("\n" + "="*50)
    print("Fabrix Server is Running Successfully!")
    print("="*50)
    print("Please DO NOT close this black window while using the software.")
    print("To stop the software, simply close this window.")
    print("="*50 + "\n")
    
    # Keep the main thread alive
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        sys.exit(0)
