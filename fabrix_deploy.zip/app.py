import os
import csv
import io
import pandas as pd
from flask import Flask, render_template, request, redirect, url_for, jsonify, flash, Response, send_file
from datetime import datetime, timedelta
from models import db, Product, Invoice, InvoiceItem

app = Flask(__name__)
app.secret_key = 'fabrix_super_secret_key'
# Set absolute path for SQLite to ensure it works anywhere
db_path = os.path.join(os.path.abspath(os.path.dirname(__name__)), 'fabrix.db')
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

with app.app_context():
    db.create_all()

@app.route('/')
def dashboard():
    total_products = Product.query.count()
    total_stock = sum([p.stock for p in Product.query.all()])
    
    # Calculate today's sales
    today = datetime.utcnow().date()
    today_invoices = Invoice.query.filter(Invoice.date >= today).all()
    today_sales = sum([inv.total_amount for inv in today_invoices])
    today_profit = sum([inv.total_profit for inv in today_invoices])

    return render_template('dashboard.html', total_products=total_products, total_stock=total_stock, today_sales=today_sales, today_profit=today_profit)

@app.route('/inventory', methods=['GET', 'POST'])
def inventory():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'add':
            name = request.form.get('name')
            price = float(request.form.get('price', 0))
            purchase_price = float(request.form.get('purchase_price', 0))
            stock = int(request.form.get('stock', 0))
            new_product = Product(name=name, price=price, purchase_price=purchase_price, stock=stock)
            db.session.add(new_product)
            db.session.commit()
            flash('Product added successfully!', 'success')
        elif action == 'edit':
            p_id = int(request.form.get('id'))
            product = Product.query.get(p_id)
            if product:
                product.name = request.form.get('name')
                product.price = float(request.form.get('price', 0))
                product.purchase_price = float(request.form.get('purchase_price', 0))
                product.stock = int(request.form.get('stock', 0))
                db.session.commit()
                flash('Product updated successfully!', 'success')
        elif action == 'delete':
            p_id = int(request.form.get('id'))
            product = Product.query.get(p_id)
            if product:
                db.session.delete(product)
                db.session.commit()
                flash('Product deleted successfully!', 'success')
        elif action == 'bulk_add':
            if 'file' not in request.files:
                flash('No file uploaded', 'danger')
                return redirect(url_for('inventory'))
            file = request.files['file']
            if file.filename == '':
                flash('No selected file', 'danger')
                return redirect(url_for('inventory'))
            
            if file and file.filename.endswith('.csv'):
                try:
                    stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
                    csv_input = csv.reader(stream)
                    header = next(csv_input) # Skip header
                    
                    added_count = 0
                    for row in csv_input:
                        if len(row) >= 4:
                            # Expected format based on image: Product Name, Qty, Selling Price, Price for us
                            name = row[0].strip()
                            stock = int(row[1].strip() or 0)
                            price = float(row[2].strip() or 0.0)
                            purchase_price = float(row[3].strip() or 0.0)
                            
                            new_product = Product(name=name, price=price, purchase_price=purchase_price, stock=stock)
                            db.session.add(new_product)
                            added_count += 1
                    
                    db.session.commit()
                    flash(f'Successfully added {added_count} products from CSV!', 'success')
                except Exception as e:
                    flash(f'Error processing file: {str(e)}', 'danger')
            else:
                flash('Please upload a valid CSV file.', 'danger')
                
        return redirect(url_for('inventory'))
    
    products = Product.query.all()
    return render_template('inventory.html', products=products)

@app.route('/download-demo')
def download_demo():
    df = pd.DataFrame({
        'Product Name': ['Jeans', 'Shirts'],
        'Qty': [200, 300],
        'Selling Price': [1000, 600],
        'Price for us': [440, 380]
    })
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Sheet1')
    output.seek(0)
    
    return Response(
        output.getvalue(),
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={"Content-disposition": "attachment; filename=demo_inventory.xlsx"}
    )

@app.route('/api/bulk_add', methods=['POST'])
def api_bulk_add():
    data = request.json
    added_count = 0
    try:
        for row in data:
            new_product = Product(
                name=row['name'],
                stock=int(row['qty']),
                price=float(row['price']),
                purchase_price=float(row['purchase_price'])
            )
            db.session.add(new_product)
            added_count += 1
        db.session.commit()
        return jsonify({'success': True, 'count': added_count})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/products')
def api_products():
    products = Product.query.all()
    return jsonify([p.to_dict() for p in products])

@app.route('/billing', methods=['GET', 'POST'])
def billing():
    if request.method == 'POST':
        data = request.json
        customer_name = data.get('customer_name')
        customer_phone = data.get('customer_phone')
        payment_mode = data.get('payment_mode', 'UPI')
        discount_percent = float(data.get('discount_percent', 0))
        gst_percent = float(data.get('gst_percent', 0))
        items = data.get('items', [])
        
        if not items:
            return jsonify({'success': False, 'message': 'No items in the bill'})

        subtotal = 0
        total_purchase_cost = 0
        invoice_items = []
        for item in items:
            product = Product.query.get(item['product_id'])
            if not product or product.stock < int(item['quantity']):
                return jsonify({'success': False, 'message': f'Insufficient stock for {item["product_name"]}'})
            
            qty = int(item['quantity'])
            price = float(item['price'])
            total = qty * price
            subtotal += total
            
            # Calculate cost & profit for this item
            item_purchase_cost = qty * product.purchase_price
            total_purchase_cost += item_purchase_cost
            item_profit = total - item_purchase_cost
            
            # Deduct stock
            product.stock -= qty
            
            inv_item = InvoiceItem(
                product_id=product.id,
                product_name=product.name,
                quantity=qty,
                price=price,
                purchase_price=product.purchase_price,
                total=total,
                profit=item_profit
            )
            invoice_items.append(inv_item)
            
        discount_amount = subtotal * (discount_percent / 100)
        after_discount = subtotal - discount_amount
        gst_amount = after_discount * (gst_percent / 100)
        total_amount = after_discount + gst_amount
        
        # Calculate total profit (After discount, before GST)
        total_profit = after_discount - total_purchase_cost
        
        # Generate Invoice ID
        inv_number = f"INV-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
        
        invoice = Invoice(
            invoice_number=inv_number,
            customer_name=customer_name,
            customer_phone=customer_phone,
            payment_mode=payment_mode,
            subtotal=subtotal,
            discount_percent=discount_percent,
            discount_amount=discount_amount,
            gst_percent=gst_percent,
            gst_amount=gst_amount,
            total_amount=total_amount,
            total_profit=total_profit
        )
        
        db.session.add(invoice)
        db.session.commit() # Commit to get invoice ID
        
        for item in invoice_items:
            item.invoice_id = invoice.id
            db.session.add(item)
            
        db.session.commit()
        return jsonify({'success': True, 'invoice_id': invoice.id})

    return render_template('billing.html')

@app.route('/invoice/<int:id>')
def view_invoice(id):
    invoice = Invoice.query.get_or_404(id)
    return render_template('invoice.html', invoice=invoice)

@app.route('/reports')
def reports():
    period = request.args.get('period', 'monthly')
    now = datetime.utcnow()
    
    if period == 'monthly':
        start_date = now - timedelta(days=30)
    elif period == '3months':
        start_date = now - timedelta(days=90)
    elif period == '6months':
        start_date = now - timedelta(days=180)
    elif period == 'yearly':
        start_date = now - timedelta(days=365)
    else:
        start_date = now - timedelta(days=30)

    invoices = Invoice.query.filter(Invoice.date >= start_date).order_by(Invoice.date.desc()).all()
    
    total_sales = sum([inv.total_amount for inv in invoices])
    total_profit = sum([inv.total_profit for inv in invoices])
    total_invoices = len(invoices)
    
    return render_template('reports.html', invoices=invoices, period=period, total_sales=total_sales, total_profit=total_profit, total_invoices=total_invoices)

if __name__ == '__main__':
    # Listen on all interfaces so phone can access via IP
    app.run(host='0.0.0.0', port=5000, debug=True)
